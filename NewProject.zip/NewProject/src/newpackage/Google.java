package newpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Google {
	public String baseUrl = "https://www.google.co.in/";
	static WebDriver driver = null;

	@BeforeTest
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(baseUrl);
		driver.manage().window().maximize();
	}

	@Test(priority = 0)
	public void test() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"gb\"]/div/div[2]/a")).click();
		Thread.sleep(5000);
//Entering Email ID		
		driver.findElement(By.xpath("//*[@id=\"identifierId\"]")).sendKeys("newnameabc123@gmail.com", Keys.ENTER);
		Thread.sleep(3000);
//Entring Passwaord		
		driver.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).sendKeys("newnameabc",
				Keys.ENTER);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"gb\"]/div/div[1]/div/div[1]/a")).click();
		Thread.sleep(8000);
		driver.findElement(By.xpath("//*[@id=\":3c\"]/div/div")).click();
		Thread.sleep(3000);
//Add Emailer
		driver.findElement(By.xpath("//*[@id=\":8y\"]")).sendKeys("suvit.chitnis@gmail.com", Keys.ENTER);
		Thread.sleep(5000);
//Message in Subject
		driver.findElement(By.name("subjectbox")).sendKeys("Test Upload and sent message ");
		Thread.sleep(5000);
//Message-in-Mail
		driver.findElement(By.xpath("//*[@id=\":9l\"]")).sendKeys("Hi");
		Thread.sleep(3000);
//Adding Documents		
		driver.findElement(By.xpath("//*[@id=\":9y\"]")).click();
		Thread.sleep(20000);
//Submit 		
		driver.findElement(By.xpath("//*[@id=\":86\"]")).click();
		Thread.sleep(5000);
//Sent message folder in Email		
		driver.findElement(By.xpath("//*[@id=\"gs_lc50\"]/input[1]")).sendKeys("in:sent ", Keys.ENTER);
		Thread.sleep(10000);
		driver.close();
	}
}
